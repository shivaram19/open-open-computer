import React, { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { ArrowLeft, ChevronRight, Target, DollarSign, Users, TrendingUp, AlertCircle } from 'lucide-react';
import { metaCampaigns, metaAdSets, metaAds, googleCampaigns, googleKeywords } from '../data/mockData';

const StatusBadge = ({ status }) => {
  const styles = {
    active: 'badge-green',
    paused: 'badge-amber',
    stopped: 'badge-red'
  };
  return <span className={`badge ${styles[status] || 'badge-gray'}`}>{status}</span>;
};

const CampaignRow = ({ campaign, onClick, isMeta }) => (
  <tr className="cursor-pointer" onClick={onClick}>
    <td>
      <div className="flex items-center gap-2">
        <div className={`rounded-full ${isMeta ? 'bg-blue-500' : 'bg-emerald-500'}`} style={{width:8,height:8}} />
        <span className="font-medium text-slate-700">{campaign.name}</span>
      </div>
    </td>
    <td><StatusBadge status={campaign.status} /></td>
    <td className="text-right font-medium">${campaign.spend.toLocaleString()}</td>
    <td className="text-right">{campaign.leads}</td>
    <td className="text-right">${campaign.cpl}</td>
    <td className="text-right">{campaign.enrollments}</td>
    <td className="text-right font-semibold">${campaign.revenue.toLocaleString()}</td>
    <td className="text-right">
      <span className={`font-bold ${campaign.roas >= 20 ? 'text-emerald-600' : campaign.roas >= 10 ? 'text-blue-600' : 'text-red-600'}`}>
        {campaign.roas}x
      </span>
    </td>
    <td><ChevronRight size={16} className="text-slate-400" /></td>
  </tr>
);

export default function CampaignDrillDown() {
  const [platform, setPlatform] = useState('meta');
  const [selectedCampaign, setSelectedCampaign] = useState(null);
  const [selectedAdSet, setSelectedAdSet] = useState(null);

  const campaigns = platform === 'meta' ? metaCampaigns : googleCampaigns;

  const handleCampaignClick = (campaign) => {
    setSelectedCampaign(campaign);
    setSelectedAdSet(null);
  };

  const handleAdSetClick = (adSet) => {
    setSelectedAdSet(adSet);
  };

  const handleBack = () => {
    if (selectedAdSet) {
      setSelectedAdSet(null);
    } else if (selectedCampaign) {
      setSelectedCampaign(null);
    }
  };

  // Drill-down: Ad Sets
  if (selectedCampaign && !selectedAdSet && platform === 'meta') {
    const adSets = metaAdSets[selectedCampaign.id] || [];
    return (
      <div>
        <div className="flex items-center gap-3 mb-4">
          <button onClick={handleBack} className="flex items-center gap-1 text-sm text-slate-500 hover:text-slate-700 transition">
            <ArrowLeft size={16} /> Back to campaigns
          </button>
        </div>
        <div className="card p-5 mb-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xl font-bold text-slate-800">{selectedCampaign.name}</h3>
              <p className="text-sm text-slate-500">Ad Set Performance</p>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-xs text-slate-400">Spend</p>
                <p className="text-lg font-bold">${selectedCampaign.spend.toLocaleString()}</p>
              </div>
              <div className="text-right">
                <p className="text-xs text-slate-400">ROAS</p>
                <p className="text-lg font-bold text-emerald-600">{selectedCampaign.roas}x</p>
              </div>
            </div>
          </div>
        </div>
        <div className="card overflow-hidden">
          <div className="table-container">
            <table>
              <thead>
                <tr>
                  <th>Ad Set Name</th>
                  <th className="text-right">Spend</th>
                  <th className="text-right">Leads</th>
                  <th className="text-right">Enrollments</th>
                  <th className="text-right">Revenue</th>
                  <th className="text-right">ROAS</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {adSets.map(adSet => (
                  <tr key={adSet.id} className="cursor-pointer" onClick={() => handleAdSetClick(adSet)}>
                    <td className="font-medium text-slate-700">{adSet.name}</td>
                    <td className="text-right">${adSet.spend.toLocaleString()}</td>
                    <td className="text-right">{adSet.leads}</td>
                    <td className="text-right">{adSet.enrollments}</td>
                    <td className="text-right font-semibold">${adSet.revenue.toLocaleString()}</td>
                    <td className="text-right">
                      <span className={`font-bold ${adSet.roas >= 30 ? 'text-emerald-600' : adSet.roas >= 15 ? 'text-blue-600' : 'text-red-600'}`}>
                        {adSet.roas}x
                      </span>
                    </td>
                    <td><ChevronRight size={16} className="text-slate-400" /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  }

  // Drill-down: Ads
  if (selectedAdSet && platform === 'meta') {
    const ads = metaAds[selectedAdSet.id] || [];
    return (
      <div>
        <div className="flex items-center gap-3 mb-4">
          <button onClick={handleBack} className="flex items-center gap-1 text-sm text-slate-500 hover:text-slate-700 transition">
            <ArrowLeft size={16} /> Back to ad sets
          </button>
        </div>
        <div className="card p-5 mb-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xl font-bold text-slate-800">{selectedAdSet.name}</h3>
              <p className="text-sm text-slate-500">Individual Ad Performance</p>
            </div>
            <div className="text-right">
              <p className="text-xs text-slate-400">Ad Set ROAS</p>
              <p className="text-lg font-bold text-emerald-600">{selectedAdSet.roas}x</p>
            </div>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          {ads.map(ad => (
            <div key={ad.id} className="card p-5">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-bold text-slate-800">{ad.name}</h4>
                <span className="badge badge-gray">{ad.placement}</span>
              </div>
              <div className="grid grid-cols-3 gap-3 mb-3">
                <div className="bg-slate-50 rounded-lg p-3 text-center">
                  <p className="text-xs text-slate-500">Spend</p>
                  <p className="text-lg font-bold">${ad.spend.toLocaleString()}</p>
                </div>
                <div className="bg-slate-50 rounded-lg p-3 text-center">
                  <p className="text-xs text-slate-500">Leads</p>
                  <p className="text-lg font-bold">{ad.leads}</p>
                </div>
                <div className="bg-slate-50 rounded-lg p-3 text-center">
                  <p className="text-xs text-slate-500">Enroll</p>
                  <p className="text-lg font-bold">{ad.enrollments}</p>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-500">Revenue: <strong>${ad.revenue.toLocaleString()}</strong></span>
                <span className={`font-bold text-lg ${ad.roas >= 25 ? 'text-emerald-600' : ad.roas >= 15 ? 'text-blue-600' : 'text-red-600'}`}>
                  {ad.roas}x ROAS
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // Drill-down: Google Keywords
  if (selectedCampaign && platform === 'google') {
    const keywords = googleKeywords[selectedCampaign.id] || [];
    return (
      <div>
        <div className="flex items-center gap-3 mb-4">
          <button onClick={handleBack} className="flex items-center gap-1 text-sm text-slate-500 hover:text-slate-700 transition">
            <ArrowLeft size={16} /> Back to campaigns
          </button>
        </div>
        <div className="card p-5 mb-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xl font-bold text-slate-800">{selectedCampaign.name}</h3>
              <p className="text-sm text-slate-500">Keyword Performance</p>
            </div>
            <div className="text-right">
              <p className="text-xs text-slate-400">Campaign ROAS</p>
              <p className="text-lg font-bold text-emerald-600">{selectedCampaign.roas}x</p>
            </div>
          </div>
        </div>
        <div className="card overflow-hidden">
          <div className="table-container">
            <table>
              <thead>
                <tr>
                  <th>Keyword</th>
                  <th>Match Type</th>
                  <th className="text-right">CPL</th>
                  <th className="text-right">Enroll %</th>
                  <th className="text-right">Rev/Lead</th>
                  <th>Quality</th>
                </tr>
              </thead>
              <tbody>
                {keywords.map((kw, i) => (
                  <tr key={i}>
                    <td className="font-medium text-slate-700">"{kw.text}"</td>
                    <td><span className="badge badge-blue">{kw.match_type}</span></td>
                    <td className="text-right">${kw.cpl}</td>
                    <td className="text-right">{kw.enroll_rate}%</td>
                    <td className="text-right font-semibold">${kw.rev_per_lead.toLocaleString()}</td>
                    <td>
                      <div className="flex items-center gap-2">
                        <div className="progress-bar" style={{ width: 80 }}>
                          <div className="progress-bar-fill bg-emerald-500" style={{ width: `${(kw.enroll_rate / 15) * 100}%` }} />
                        </div>
                        <span className="text-xs font-medium">{kw.enroll_rate >= 12 ? 'High' : kw.enroll_rate >= 8 ? 'Med' : 'Low'}</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  }

  // Main Campaign List
  return (
    <div>
      {/* Platform Toggle */}
      <div className="flex items-center gap-2 mb-6">
        <button
          onClick={() => { setPlatform('meta'); setSelectedCampaign(null); setSelectedAdSet(null); }}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-sm transition ${platform === 'meta' ? 'bg-blue-600 text-white' : 'bg-white border text-slate-600'}`}
        >
          <div className="rounded-full bg-white" style={{width:8,height:8}} />
          Meta Ads (Live)
        </button>
        <button
          onClick={() => { setPlatform('google'); setSelectedCampaign(null); setSelectedAdSet(null); }}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-sm transition ${platform === 'google' ? 'bg-emerald-600 text-white' : 'bg-white border text-slate-600'}`}
        >
          <div className="rounded-full bg-white" style={{width:8,height:8}} />
          Google Ads (Simulated)
        </button>
      </div>

      {/* Campaign Table */}
      <div className="card overflow-hidden">
        <div className="table-container">
          <table>
            <thead>
              <tr>
                <th>Campaign Name</th>
                <th>Status</th>
                <th className="text-right">Spend</th>
                <th className="text-right">Leads</th>
                <th className="text-right">CPL</th>
                <th className="text-right">Enroll</th>
                <th className="text-right">Revenue</th>
                <th className="text-right">ROAS</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {campaigns.map(campaign => (
                <CampaignRow
                  key={campaign.id}
                  campaign={campaign}
                  isMeta={platform === 'meta'}
                  onClick={() => handleCampaignClick(campaign)}
                />
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Performance Chart */}
      <div className="card p-5 mt-4">
        <h3 className="text-lg font-bold text-slate-800 mb-4">Campaign ROAS Comparison</h3>
        <ResponsiveContainer width="100%" height={250}>
          <BarChart data={campaigns}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
            <XAxis dataKey="name" tick={{fontSize:10, fill:'#94a3b8'}} axisLine={false} tickLine={false} interval={0} angle={-15} textAnchor="end" height={60} />
            <YAxis tick={{fontSize:11, fill:'#94a3b8'}} axisLine={false} tickLine={false} />
            <Tooltip
              formatter={(value) => [`${value}x`, 'ROAS']}
              contentStyle={{ borderRadius: 10, border: '1px solid #e2e8f0' }}
            />
            <Bar dataKey="roas" fill="#3b82f6" radius={[4, 4, 0, 0]} barSize={40}>
              {campaigns.map((entry, index) => (
                <cell key={`cell-${index}`} fill={entry.roas >= 25 ? '#10b981' : entry.roas >= 15 ? '#3b82f6' : '#ef4444'} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
