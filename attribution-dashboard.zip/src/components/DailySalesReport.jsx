import React, { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Users, Phone, Calendar, TrendingUp, Award } from 'lucide-react';
import { dailySalesReport } from '../data/mockData';

const MetricBox = ({ label, value, icon: Icon, color }) => (
  <div className="bg-slate-50 rounded-lg p-3 text-center">
    <div className={`flex items-center justify-center mb-1 ${color}`}><Icon size={16} /></div>
    <p className="text-xs text-slate-500">{label}</p>
    <p className="text-lg font-bold text-slate-800">{value}</p>
  </div>
);

export default function DailySalesReport() {
  const [activeTab, setActiveTab] = useState('call_center');
  const data = dailySalesReport;

  const callCenterChart = data.call_center.map(u => ({ name: u.name.split(' ')[0], calls: u.calls_made, appointments: u.appointments_booked, checkins: u.check_ins }));
  const salesManagerChart = data.sales_managers.map(u => ({ name: u.name.split(' ')[0], consultations: u.consultations_conducted, enrollments: u.enrollments, revenue: u.sales_amount / 1000 }));

  return (
    <div>
      <div className="card p-4 mb-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Calendar size={18} className="text-slate-400" />
          <span className="font-bold text-slate-800">{data.date}</span>
          <span className="text-sm text-slate-500">Daily Performance Report</span>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setActiveTab('call_center')} className={`px-4 py-2 rounded-lg text-sm font-medium transition ${activeTab === 'call_center' ? 'bg-blue-600 text-white' : 'bg-white border text-slate-600'}`}>Call Center</button>
          <button onClick={() => setActiveTab('sales_managers')} className={`px-4 py-2 rounded-lg text-sm font-medium transition ${activeTab === 'sales_managers' ? 'bg-emerald-600 text-white' : 'bg-white border text-slate-600'}`}>Sales Managers</button>
        </div>
      </div>

      {activeTab === 'call_center' ? (
        <div>
          <div className="grid grid-cols-3 gap-4 mb-6">
            {data.call_center.map(user => (
              <div key={user.user_id} className="card p-5">
                <div className="flex items-center gap-3 mb-4">
                  <div className="rounded-full bg-blue-100 p-2"><Users size={18} className="text-blue-600"/></div>
                  <div><h4 className="font-bold text-slate-800">{user.name}</h4><span className="badge badge-blue">Call Center</span></div>
                </div>
                <div className="grid grid-cols-3 gap-2 mb-3">
                  <MetricBox label="Calls" value={user.calls_made} icon={Phone} color="text-blue-500" />
                  <MetricBox label="Appts" value={user.appointments_booked} icon={Calendar} color="text-emerald-500" />
                  <MetricBox label="Check-ins" value={user.check_ins} icon={Users} color="text-purple-500" />
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-500">Show-up: <strong className="text-slate-700">{user.show_up_rate}%</strong></span>
                  <span className="text-slate-500">Hours: <strong className="text-slate-700">{user.hours_worked}h</strong></span>
                </div>
              </div>
            ))}
          </div>
          <div className="card p-5">
            <h3 className="text-lg font-bold text-slate-800 mb-4">Call Center Activity</h3>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={callCenterChart}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="name" tick={{fontSize:12}} axisLine={false} tickLine={false} />
                <YAxis tick={{fontSize:11}} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ borderRadius: 10, border: '1px solid #e2e8f0' }} />
                <Bar dataKey="calls" name="Calls Made" fill="#3b82f6" radius={[4,4,0,0]} barSize={40} />
                <Bar dataKey="appointments" name="Appointments" fill="#10b981" radius={[4,4,0,0]} barSize={40} />
                <Bar dataKey="checkins" name="Check-ins" fill="#a855f7" radius={[4,4,0,0]} barSize={40} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      ) : (
        <div>
          <div className="grid grid-cols-3 gap-4 mb-6">
            {data.sales_managers.map(user => (
              <div key={user.user_id} className="card p-5">
                <div className="flex items-center gap-3 mb-4">
                  <div className="rounded-full bg-emerald-100 p-2"><Award size={18} className="text-emerald-600"/></div>
                  <div><h4 className="font-bold text-slate-800">{user.name}</h4><span className="badge badge-green">Sales Manager</span></div>
                </div>
                <div className="grid grid-cols-3 gap-2 mb-3">
                  <MetricBox label="Consults" value={user.consultations_conducted} icon={Users} color="text-blue-500" />
                  <MetricBox label="Enroll" value={user.enrollments} icon={TrendingUp} color="text-emerald-500" />
                  <MetricBox label="Sales" value={`$${(user.sales_amount/1000).toFixed(0)}K`} icon={Award} color="text-amber-500" />
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-500">FAFSA: <strong className="text-slate-700">{user.fafsa_submitted} submitted</strong></span>
                  <span className="text-slate-500">Calls: <strong className="text-slate-700">{user.calls_completed}/{user.calls_attempted}</strong></span>
                </div>
              </div>
            ))}
          </div>
          <div className="card p-5">
            <h3 className="text-lg font-bold text-slate-800 mb-4">Sales Manager Performance</h3>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={salesManagerChart}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="name" tick={{fontSize:12}} axisLine={false} tickLine={false} />
                <YAxis tick={{fontSize:11}} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ borderRadius: 10, border: '1px solid #e2e8f0' }} />
                <Bar dataKey="consultations" name="Consultations" fill="#3b82f6" radius={[4,4,0,0]} barSize={40} />
                <Bar dataKey="enrollments" name="Enrollments" fill="#10b981" radius={[4,4,0,0]} barSize={40} />
                <Bar dataKey="revenue" name="Revenue ($K)" fill="#6366f1" radius={[4,4,0,0]} barSize={40} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}
    </div>
  );
}
