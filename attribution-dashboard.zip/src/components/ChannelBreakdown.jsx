import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { ArrowUpRight, ArrowDownRight, Zap, Eye } from 'lucide-react';
import { channelBreakdown } from '../data/mockData';

const COLORS = ['#3b82f6', '#10b981', '#a855f7', '#f59e0b'];

const ChannelCard = ({ channel }) => (
  <div className="card p-5">
    <div className="flex items-center justify-between mb-4">
      <div className="flex items-center gap-3">
        <div className="rounded-lg p-2" style={{ background: channel.color + '15' }}>
          <Zap size={18} style={{ color: channel.color }} />
        </div>
        <div>
          <h4 className="font-bold text-slate-800">{channel.name}</h4>
          {channel.isLive ? (
            <span className="badge badge-green">Live API</span>
          ) : (
            <span className="badge badge-amber">Demo Data</span>
          )}
        </div>
      </div>
      <div className="text-right">
        <p className="text-2xl font-extrabold text-slate-800">{channel.roas ? `${channel.roas}x` : 'N/A'}</p>
        <p className="text-xs text-slate-400">ROAS</p>
      </div>
    </div>

    <div className="grid grid-cols-2 gap-3 mb-4">
      <div className="bg-slate-50 rounded-lg p-3">
        <p className="text-xs text-slate-500">Spend</p>
        <p className="text-lg font-bold text-slate-800">${channel.spend.toLocaleString()}</p>
      </div>
      <div className="bg-slate-50 rounded-lg p-3">
        <p className="text-xs text-slate-500">Leads</p>
        <p className="text-lg font-bold text-slate-800">{channel.leads}</p>
      </div>
      <div className="bg-slate-50 rounded-lg p-3">
        <p className="text-xs text-slate-500">CPL</p>
        <p className="text-lg font-bold text-slate-800">${channel.cpl || 0}</p>
      </div>
      <div className="bg-slate-50 rounded-lg p-3">
        <p className="text-xs text-slate-500">Enrollments</p>
        <p className="text-lg font-bold text-slate-800">{channel.enrollments}</p>
      </div>
    </div>

    <div className="flex items-center justify-between text-sm">
      <span className="text-slate-500">Revenue: <strong className="text-slate-700">${channel.revenue.toLocaleString()}</strong></span>
      <span className="text-slate-500">CAC: <strong className="text-slate-700">${channel.cac || 0}</strong></span>
    </div>
  </div>
);

export default function ChannelBreakdown() {
  const pieData = channelBreakdown.map(c => ({
    name: c.name,
    value: c.leads,
    color: c.color
  }));

  const barData = channelBreakdown.map(c => ({
    name: c.name,
    leads: c.leads,
    enrollments: c.enrollments,
    revenue: c.revenue / 1000
  }));

  return (
    <div>
      {/* Channel Cards */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        {channelBreakdown.map(channel => (
          <ChannelCard key={channel.name} channel={channel} />
        ))}
      </div>

      {/* Comparison Charts */}
      <div className="grid grid-cols-2 gap-4">
        {/* Pie Chart - Lead Distribution */}
        <div className="card p-5">
          <h3 className="text-lg font-bold text-slate-800 mb-1">Lead Distribution by Channel</h3>
          <p className="text-sm text-slate-500 mb-4">Where your leads come from</p>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={pieData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={100}
                paddingAngle={4}
                dataKey="value"
              >
                {pieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                formatter={(value) => [`${value} leads`, '']}
                contentStyle={{ borderRadius: 10, border: '1px solid #e2e8f0' }}
              />
              <Legend verticalAlign="bottom" height={36} iconType="circle" />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Bar Chart - Performance Comparison */}
        <div className="card p-5">
          <h3 className="text-lg font-bold text-slate-800 mb-1">Channel Performance</h3>
          <p className="text-sm text-slate-500 mb-4">Leads vs. Enrollments vs. Revenue ($K)</p>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={barData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="name" tick={{fontSize:11, fill:'#94a3b8'}} axisLine={false} tickLine={false} />
              <YAxis tick={{fontSize:11, fill:'#94a3b8'}} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{ borderRadius: 10, border: '1px solid #e2e8f0' }}
                formatter={(value, name) => [name === 'revenue' ? `$${value}K` : value, name]}
              />
              <Legend />
              <Bar dataKey="leads" name="Leads" fill="#3b82f6" radius={[4, 4, 0, 0]} barSize={30} />
              <Bar dataKey="enrollments" name="Enrollments" fill="#10b981" radius={[4, 4, 0, 0]} barSize={30} />
              <Bar dataKey="revenue" name="Revenue ($K)" fill="#6366f1" radius={[4, 4, 0, 0]} barSize={30} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Insights */}
      <div className="card p-5 mt-4">
        <h3 className="text-lg font-bold text-slate-800 mb-3">Channel Insights</h3>
        <div className="grid grid-cols-2 gap-4">
          <div className="flex items-start gap-3 bg-emerald-50 rounded-lg p-4">
            <ArrowUpRight size={20} className="text-emerald-600 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-emerald-800">Google has 67% higher ROAS than Meta</p>
              <p className="text-xs text-emerald-600 mt-1">Google: 32.0x ROAS vs. Meta: 19.2x. Consider shifting 20% of Meta budget to Google Search.</p>
            </div>
          </div>
          <div className="flex items-start gap-3 bg-blue-50 rounded-lg p-4">
            <Eye size={20} className="text-blue-600 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-blue-800">Referral leads have highest enrollment rate</p>
              <p className="text-xs text-blue-600 mt-1">10% enrollment rate with $0 CAC. Invest more in student referral incentives.</p>
            </div>
          </div>
          <div className="flex items-start gap-3 bg-amber-50 rounded-lg p-4">
            <ArrowDownRight size={20} className="text-amber-600 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-amber-800">Organic Search leads have low show-up rate</p>
              <p className="text-xs text-amber-600 mt-1">31% show-up rate vs. 70%+ for paid channels. Improve landing page pre-qualification.</p>
            </div>
          </div>
          <div className="flex items-start gap-3 bg-purple-50 rounded-lg p-4">
            <Zap size={20} className="text-purple-600 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-purple-800">Meta generates volume but lower quality</p>
              <p className="text-xs text-purple-600 mt-1">45% of leads but only 43% of revenue. Focus Meta budget on lookalike audiences.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
