import React, { useState } from 'react';
import { ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ZAxis, Cell } from 'recharts';
import { ArrowUpRight, ArrowDownRight, Star, Filter } from 'lucide-react';
import { leadQualityMatrix } from '../data/mockData';

const QualityBadge = ({ score }) => {
  if (score >= 9) return <span className="badge badge-green">Excellent</span>;
  if (score >= 7) return <span className="badge badge-blue">Good</span>;
  if (score >= 5) return <span className="badge badge-amber">Average</span>;
  return <span className="badge badge-red">Poor</span>;
};

const CustomScatterTooltip = ({ active, payload }) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="bg-white border rounded-lg shadow-lg p-3" style={{ minWidth: 200 }}>
        <p className="font-bold text-slate-800 mb-1">{data.name}</p>
        <div className="space-y-1 text-xs">
          <div className="flex justify-between"><span className="text-slate-500">CPL:</span><span className="font-semibold">${data.cpl}</span></div>
          <div className="flex justify-between"><span className="text-slate-500">Leads:</span><span className="font-semibold">{data.leads}</span></div>
          <div className="flex justify-between"><span className="text-slate-500">Enrollment Rate:</span><span className="font-semibold">{data.enrollment_rate}%</span></div>
          <div className="flex justify-between"><span className="text-slate-500">Revenue/Lead:</span><span className="font-semibold">${data.revenue_per_lead}</span></div>
          <div className="flex justify-between"><span className="text-slate-500">ROAS:</span><span className="font-semibold text-emerald-600">{data.roas}x</span></div>
          <div className="flex justify-between"><span className="text-slate-500">Quality Score:</span><span className="font-semibold">{data.quality_score}/10</span></div>
        </div>
      </div>
    );
  }
  return null;
};

export default function LeadQualityMatrix() {
  const [sortBy, setSortBy] = useState('quality_score');
  const [filterPlatform, setFilterPlatform] = useState('all');

  const sortedData = [...leadQualityMatrix]
    .filter(c => filterPlatform === 'all' || c.platform === filterPlatform)
    .sort((a, b) => b[sortBy] - a[sortBy]);

  const scatterData = leadQualityMatrix.map(c => ({
    ...c,
    x: c.cpl,
    y: c.enrollment_rate,
    z: c.revenue_per_lead / 100
  }));

  return (
    <div>
      {/* Scatter Plot */}
      <div className="card p-5 mb-4">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-bold text-slate-800">Lead Quality Matrix</h3>
            <p className="text-sm text-slate-500">CPL vs. Enrollment Rate (bubble size = revenue per lead)</p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">X: Cost per Lead</span>
            <span className="text-xs text-slate-400">|</span>
            <span className="text-xs text-slate-400">Y: Enrollment %</span>
          </div>
        </div>
        <ResponsiveContainer width="100%" height={350}>
          <ScatterChart>
            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
            <XAxis type="number" dataKey="x" name="CPL" unit="$" tick={{fontSize:11, fill:'#94a3b8'}} axisLine={false} tickLine={false} label={{ value: 'Cost per Lead ($)', position: 'bottom', offset: 0, style: { fontSize: 12, fill: '#94a3b8' } }} />
            <YAxis type="number" dataKey="y" name="Enrollment Rate" unit="%" tick={{fontSize:11, fill:'#94a3b8'}} axisLine={false} tickLine={false} label={{ value: 'Enrollment Rate (%)', angle: -90, position: 'insideLeft', style: { fontSize: 12, fill: '#94a3b8' } }} />
            <ZAxis type="number" dataKey="z" range={[50, 400]} />
            <Tooltip content={<CustomScatterTooltip />} cursor={{ strokeDasharray: '3 3' }} />
            <Scatter name="Campaigns" data={scatterData} fill="#3b82f6">
              {scatterData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.platform === 'google' ? '#10b981' : '#3b82f6'} />
              ))}
            </Scatter>
          </ScatterChart>
        </ResponsiveContainer>
        <div className="flex items-center justify-center gap-4 mt-2">
          <div className="flex items-center gap-1 text-xs text-slate-500"><div className="rounded-full bg-blue-500" style={{width:10,height:10}}/> Meta</div>
          <div className="flex items-center gap-1 text-xs text-slate-500"><div className="rounded-full bg-emerald-500" style={{width:10,height:10}}/> Google</div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3 mb-4">
        <div className="flex items-center gap-2 bg-white border rounded-lg px-3 py-2">
          <Filter size={14} className="text-slate-400" />
          <select
            className="text-sm text-slate-600 bg-transparent border-none outline-none cursor-pointer"
            value={filterPlatform}
            onChange={(e) => setFilterPlatform(e.target.value)}
          >
            <option value="all">All Platforms</option>
            <option value="meta">Meta Only</option>
            <option value="google">Google Only</option>
          </select>
        </div>
        <div className="flex items-center gap-2 bg-white border rounded-lg px-3 py-2">
          <span className="text-sm text-slate-500">Sort by:</span>
          <select
            className="text-sm text-slate-600 bg-transparent border-none outline-none cursor-pointer"
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
          >
            <option value="quality_score">Quality Score</option>
            <option value="roas">ROAS</option>
            <option value="cpl">CPL (low to high)</option>
            <option value="enrollment_rate">Enrollment Rate</option>
            <option value="revenue_per_lead">Revenue per Lead</option>
          </select>
        </div>
      </div>

      {/* Quality Table */}
      <div className="card overflow-hidden">
        <div className="table-container">
          <table>
            <thead>
              <tr>
                <th>Campaign</th>
                <th>Platform</th>
                <th className="text-right">CPL</th>
                <th className="text-right">Leads</th>
                <th className="text-right">Qual %</th>
                <th className="text-right">Appt %</th>
                <th className="text-right">Show-up %</th>
                <th className="text-right">Enroll %</th>
                <th className="text-right">Rev/Lead</th>
                <th className="text-right">ROAS</th>
                <th>Quality</th>
              </tr>
            </thead>
            <tbody>
              {sortedData.map((campaign, i) => (
                <tr key={i}>
                  <td>
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-slate-700">{campaign.name}</span>
                    </div>
                  </td>
                  <td>
                    <span className={`badge ${campaign.platform === 'google' ? 'badge-green' : 'badge-blue'}`}>
                      {campaign.platform}
                    </span>
                  </td>
                  <td className="text-right">${campaign.cpl}</td>
                  <td className="text-right">{campaign.leads}</td>
                  <td className="text-right">{campaign.qualified_rate}%</td>
                  <td className="text-right">{campaign.appointment_rate}%</td>
                  <td className="text-right">{campaign.showup_rate}%</td>
                  <td className="text-right font-semibold">{campaign.enrollment_rate}%</td>
                  <td className="text-right font-semibold">${campaign.revenue_per_lead.toLocaleString()}</td>
                  <td className="text-right">
                    <span className={`font-bold ${campaign.roas >= 30 ? 'text-emerald-600' : campaign.roas >= 20 ? 'text-blue-600' : 'text-red-600'}`}>
                      {campaign.roas}x
                    </span>
                  </td>
                  <td>
                    <div className="flex items-center gap-2">
                      <div className="progress-bar" style={{ width: 60 }}>
                        <div
                          className="progress-bar-fill"
                          style={{
                            width: `${campaign.quality_score * 10}%`,
                            background: campaign.quality_score >= 9 ? '#10b981' : campaign.quality_score >= 7 ? '#3b82f6' : campaign.quality_score >= 5 ? '#f59e0b' : '#ef4444'
                          }}
                        />
                      </div>
                      <span className="text-xs font-bold">{campaign.quality_score}</span>
                      <QualityBadge score={campaign.quality_score} />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Insights */}
      <div className="grid grid-cols-2 gap-4 mt-4">
        <div className="flex items-start gap-3 bg-emerald-50 rounded-lg p-4">
          <ArrowUpRight size={20} className="text-emerald-600 mt-0.5" />
          <div>
            <p className="text-sm font-semibold text-emerald-800">Top Performer: Google Nursing Search</p>
            <p className="text-xs text-emerald-600 mt-1">$55 CPL, 12.5% enrollment rate, $2,000 revenue per lead. Quality Score: 9.8/10. Increase bids by 20%.</p>
          </div>
        </div>
        <div className="flex items-start gap-3 bg-red-50 rounded-lg p-4">
          <ArrowDownRight size={20} className="text-red-600 mt-0.5" />
          <div>
            <p className="text-sm font-semibold text-red-800">Underperformer: Meta Careers Fair</p>
            <p className="text-xs text-red-600 mt-1">$75 CPL, 2.5% enrollment rate, $400 revenue per lead. Quality Score: 4.2/10. Pause immediately.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
