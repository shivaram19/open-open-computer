import React, { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { AlertTriangle, TrendingDown, Filter, ArrowRight } from 'lucide-react';
import { lostLeadAnalysis } from '../data/mockData';

const COLORS = ['#ef4444', '#f59e0b', '#3b82f6', '#10b981', '#a855f7', '#6366f1', '#ec4899', '#14b8a6', '#f97316', '#8b5cf6'];

const StageBar = ({ stage, count, percentage, total }) => (
  <div className="mb-3">
    <div className="flex items-center justify-between mb-1">
      <span className="text-sm font-medium text-slate-700">{stage}</span>
      <span className="text-sm text-slate-500">{count} leads ({percentage}%)</span>
    </div>
    <div className="progress-bar">
      <div className="progress-bar-fill bg-red-500" style={{ width: `${(count / total) * 100}%` }} />
    </div>
  </div>
);

export default function LostLeadAnalysis() {
  const [filterSource, setFilterSource] = useState('all');
  const data = lostLeadAnalysis;
  const filteredReasons = filterSource === 'all' ? data.by_reason : data.by_source_and_reason[filterSource] || data.by_reason;
  const pieData = data.by_source.map(s => ({ name: s.source, value: s.lost }));

  return (
    <div>
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="card p-5 flex items-center gap-4">
          <div className="rounded-full bg-red-50 p-3"><AlertTriangle size={24} className="text-red-600"/></div>
          <div>
            <p className="text-xs text-slate-500 font-medium">Total Lost Leads</p>
            <p className="text-3xl font-extrabold text-slate-800">{data.summary.total_lost}</p>
            <p className="text-sm text-red-600 font-medium">{data.summary.lost_percentage}% of all leads</p>
          </div>
        </div>
        <div className="card p-5 flex items-center gap-4">
          <div className="rounded-full bg-amber-50 p-3"><TrendingDown size={24} className="text-amber-600"/></div>
          <div>
            <p className="text-xs text-slate-500 font-medium">Potential Revenue Lost</p>
            <p className="text-3xl font-extrabold text-slate-800">${(data.summary.total_potential_revenue/1000000).toFixed(1)}M</p>
            <p className="text-sm text-amber-600 font-medium">Based on avg deal value</p>
          </div>
        </div>
        <div className="card p-5 flex items-center gap-4">
          <div className="rounded-full bg-blue-50 p-3"><ArrowRight size={24} className="text-blue-600"/></div>
          <div>
            <p className="text-xs text-slate-500 font-medium">Biggest Drop-off Stage</p>
            <p className="text-3xl font-extrabold text-slate-800">Consultation</p>
            <p className="text-sm text-blue-600 font-medium">26.7% of all losses</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="card p-5">
          <h3 className="text-lg font-bold text-slate-800 mb-4">Lost Leads by Source</h3>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie data={pieData} cx="50%" cy="50%" innerRadius={50} outerRadius={90} paddingAngle={3} dataKey="value">
                {pieData.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
              </Pie>
              <Tooltip formatter={(value) => [`${value} leads`, '']} contentStyle={{ borderRadius: 10, border: '1px solid #e2e8f0' }} />
              <Legend verticalAlign="bottom" height={36} iconType="circle" />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="card p-5">
          <h3 className="text-lg font-bold text-slate-800 mb-4">Losses by Pipeline Stage</h3>
          <div className="overflow-y-auto" style={{ maxHeight: 250 }}>
            {data.by_stage.map(s => (
              <StageBar key={s.stage} stage={s.stage.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())} count={s.lost} percentage={s.percentage} total={data.summary.total_lost} />
            ))}
          </div>
        </div>
      </div>

      <div className="card p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold text-slate-800">Reasons for Lost Leads</h3>
          <div className="flex items-center gap-2 bg-white border rounded-lg px-3 py-2">
            <Filter size={14} className="text-slate-400" />
            <select className="text-sm text-slate-600 bg-transparent border-none outline-none cursor-pointer" value={filterSource} onChange={(e) => setFilterSource(e.target.value)}>
              <option value="all">All Sources</option>
              <option value="Meta">Meta Only</option>
              <option value="Google">Google Only</option>
            </select>
          </div>
        </div>
        <div className="table-container">
          <table>
            <thead><tr><th>Reason</th><th className="text-right">Count</th><th className="text-right">Percentage</th><th>Distribution</th></tr></thead>
            <tbody>
              {filteredReasons.map((reason, i) => (
                <tr key={i}>
                  <td className="font-medium text-slate-700">{reason.reason}</td>
                  <td className="text-right">{reason.count}</td>
                  <td className="text-right">{reason.percentage}%</td>
                  <td><div className="flex items-center gap-2"><div className="progress-bar" style={{ width: 120 }}><div className="progress-bar-fill bg-red-500" style={{ width: `${reason.percentage * 3}%` }} /></div></div></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
