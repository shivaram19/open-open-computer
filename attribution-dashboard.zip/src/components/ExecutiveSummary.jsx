import React from 'react';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, Legend
} from 'recharts';
import { TrendingUp, TrendingDown, Users, DollarSign, Target, Percent, AlertCircle, Award } from 'lucide-react';
import { executiveSummary, funnelData } from '../data/mockData';

const MetricCard = ({ title, value, change, changeType, icon: Icon, prefix = '', suffix = '', subtext = '' }) => (
  <div className="card p-5">
    <div className="flex items-start justify-between mb-3">
      <div>
        <p className="text-sm text-slate-500 font-medium">{title}</p>
        <h3 className="text-2xl font-extrabold text-slate-800 mt-1">
          {prefix}{typeof value === 'number' ? value.toLocaleString() : value}{suffix}
        </h3>
      </div>
      <div className={`rounded-lg p-2 ${changeType === 'positive' ? 'bg-emerald-50' : changeType === 'negative' ? 'bg-red-50' : 'bg-slate-50'}`}>
        <Icon size={20} className={changeType === 'positive' ? 'text-emerald-600' : changeType === 'negative' ? 'text-red-600' : 'text-slate-500'} />
      </div>
    </div>
    {change !== undefined && (
      <div className="flex items-center gap-1">
        {changeType === 'positive' ? <TrendingUp size={14} className="text-emerald-600" /> : <TrendingDown size={14} className="text-red-600" />}
        <span className={`text-sm font-semibold ${changeType === 'positive' ? 'text-emerald-600' : 'text-red-600'}`}>
          {change > 0 ? '+' : ''}{change}%
        </span>
        <span className="text-xs text-slate-400 ml-1">vs last month</span>
      </div>
    )}
    {subtext && <p className="text-xs text-slate-400 mt-1">{subtext}</p>}
  </div>
);

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white border rounded-lg shadow-lg p-3">
        <p className="text-sm font-semibold text-slate-700 mb-2">{label}</p>
        {payload.map((p, i) => (
          <div key={i} className="flex items-center gap-2 text-xs mb-1">
            <div className="rounded-full" style={{ width: 8, height: 8, background: p.color }} />
            <span className="text-slate-500">{p.name}:</span>
            <span className="font-semibold text-slate-700">
              {p.name === 'Revenue' ? '$' + p.value.toLocaleString() : p.value}
            </span>
          </div>
        ))}
      </div>
    );
  }
  return null;
};

export default function ExecutiveSummary() {
  const s = executiveSummary.summary;

  return (
    <div>
      {/* KPI Grid */}
      <div className="grid grid-cols-5 gap-4 mb-6">
        <MetricCard title="Marketing Spend" value={s.total_marketing_spend} prefix="$" change={-12} changeType="positive" icon={DollarSign} subtext="Budget efficiency improved" />
        <MetricCard title="Total Leads" value={s.total_leads} change={18} changeType="positive" icon={Users} subtext="+75 vs last month" />
        <MetricCard title="Enrollments" value={s.enrollments} change={8} changeType="positive" icon={Award} subtext={`${s.lead_to_enrollment_rate}% conversion rate`} />
        <MetricCard title="Revenue" value={s.total_revenue} prefix="$" change={24} changeType="positive" icon={TrendingUp} subtext="Strong month" />
        <MetricCard title="ROAS" value={s.roas} suffix="x" change={15} changeType="positive" icon={Target} subtext={`CAC: $${s.cac}`} />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        {/* Trend Chart */}
        <div className="card p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-bold text-slate-800">Daily Trend</h3>
              <p className="text-sm text-slate-500">Leads, Enrollments & Revenue</p>
            </div>
            <div className="flex items-center gap-4 text-xs">
              <div className="flex items-center gap-1"><div className="rounded-full bg-blue-500" style={{width:8,height:8}}/> Leads</div>
              <div className="flex items-center gap-1"><div className="rounded-full bg-emerald-500" style={{width:8,height:8}}/> Enrollments</div>
              <div className="flex items-center gap-1"><div className="rounded-full bg-indigo-500" style={{width:8,height:8}}/> Revenue ($K)</div>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={executiveSummary.trend}>
              <defs>
                <linearGradient id="colorLeads" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#3b82f6" stopOpacity={0.15}/><stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/></linearGradient>
                <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#6366f1" stopOpacity={0.15}/><stop offset="95%" stopColor="#6366f1" stopOpacity={0}/></linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="date" tick={{fontSize:11, fill:'#94a3b8'}} axisLine={false} tickLine={false} />
              <YAxis yAxisId="left" tick={{fontSize:11, fill:'#94a3b8'}} axisLine={false} tickLine={false} />
              <YAxis yAxisId="right" orientation="right" tick={{fontSize:11, fill:'#94a3b8'}} axisLine={false} tickLine={false} tickFormatter={(v) => `$${v/1000}K`} />
              <Tooltip content={<CustomTooltip />} />
              <Area yAxisId="left" type="monotone" dataKey="leads" name="Leads" stroke="#3b82f6" strokeWidth={2} fill="url(#colorLeads)" />
              <Area yAxisId="left" type="monotone" dataKey="enrollments" name="Enrollments" stroke="#10b981" strokeWidth={2} fill="none" />
              <Area yAxisId="right" type="monotone" dataKey="revenue" name="Revenue" stroke="#6366f1" strokeWidth={2} fill="url(#colorRev)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Funnel Chart */}
        <div className="card p-5">
          <div className="mb-4">
            <h3 className="text-lg font-bold text-slate-800">Enrollment Funnel</h3>
            <p className="text-sm text-slate-500">Lead progression through pipeline stages</p>
          </div>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={funnelData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" horizontal={false} />
              <XAxis type="number" tick={{fontSize:11, fill:'#94a3b8'}} axisLine={false} tickLine={false} />
              <YAxis dataKey="stage" type="category" tick={{fontSize:11, fill:'#64748b', fontWeight:500}} axisLine={false} tickLine={false} width={100} />
              <Tooltip
                formatter={(value, name) => [value, 'Leads']}
                contentStyle={{ borderRadius: 10, border: '1px solid #e2e8f0', boxShadow: '0 4px 6px rgba(0,0,0,0.08)' }}
              />
              <Bar dataKey="count" fill="#3b82f6" radius={[0, 4, 4, 0]} barSize={24}>
                {funnelData.map((entry, index) => (
                  <cell key={`cell-${index}`} fill={index < 2 ? '#3b82f6' : index < 5 ? '#6366f1' : index < 8 ? '#a855f7' : '#10b981'} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Bottom Stats */}
      <div className="grid grid-cols-4 gap-4">
        <div className="card p-4 flex items-center gap-4">
          <div className="rounded-full bg-blue-50 p-3"><Percent size={20} className="text-blue-600"/></div>
          <div>
            <p className="text-xs text-slate-500 font-medium">Lead to Appointment</p>
            <p className="text-xl font-bold text-slate-800">{s.lead_to_appointment_rate}%</p>
          </div>
        </div>
        <div className="card p-4 flex items-center gap-4">
          <div className="rounded-full bg-emerald-50 p-3"><Users size={20} className="text-emerald-600"/></div>
          <div>
            <p className="text-xs text-slate-500 font-medium">Show-up Rate</p>
            <p className="text-xl font-bold text-slate-800">{s.appointment_to_checkin_rate}%</p>
          </div>
        </div>
        <div className="card p-4 flex items-center gap-4">
          <div className="rounded-full bg-amber-50 p-3"><DollarSign size={20} className="text-amber-600"/></div>
          <div>
            <p className="text-xs text-slate-500 font-medium">Avg Deal Value</p>
            <p className="text-xl font-bold text-slate-800">${s.average_deal_value.toLocaleString()}</p>
          </div>
        </div>
        <div className="card p-4 flex items-center gap-4">
          <div className="rounded-full bg-red-50 p-3"><AlertCircle size={20} className="text-red-600"/></div>
          <div>
            <p className="text-xs text-slate-500 font-medium">Lost Leads</p>
            <p className="text-xl font-bold text-slate-800">{s.lost_leads} <span className="text-sm font-normal text-slate-400">({s.lost_lead_percentage}%)</span></p>
          </div>
        </div>
      </div>
    </div>
  );
}
