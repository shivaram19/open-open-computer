import React, { useState } from 'react';
import {
  LayoutDashboard, BarChart3, Target, Award, AlertTriangle, Users,
  TrendingUp, Activity, ChevronDown, Calendar, Filter
} from 'lucide-react';
import ExecutiveSummary from './components/ExecutiveSummary';
import ChannelBreakdown from './components/ChannelBreakdown';
import CampaignDrillDown from './components/CampaignDrillDown';
import LeadQualityMatrix from './components/LeadQualityMatrix';
import LostLeadAnalysis from './components/LostLeadAnalysis';
import DailySalesReport from './components/DailySalesReport';

const NAV_ITEMS = [
  { id: 'executive', label: 'Executive Summary', icon: LayoutDashboard },
  { id: 'channel', label: 'Channel Breakdown', icon: BarChart3 },
  { id: 'campaign', label: 'Campaign Drill-Down', icon: Target },
  { id: 'quality', label: 'Lead Quality', icon: Award },
  { id: 'lost', label: 'Lost Leads', icon: AlertTriangle },
  { id: 'sales', label: 'Daily Sales', icon: Users },
];

const DateRangeSelector = () => (
  <div className="flex items-center gap-2 bg-white border rounded-lg px-3 py-2 text-sm text-slate-600">
    <Calendar size={14} />
    <span>Aug 1 - Aug 31, 2026</span>
    <ChevronDown size={14} />
  </div>
);

const PlatformFilter = () => (
  <div className="flex items-center gap-2 bg-white border rounded-lg px-3 py-2 text-sm text-slate-600">
    <Filter size={14} />
    <span>All Platforms</span>
    <ChevronDown size={14} />
  </div>
);

export default function App() {
  const [activeView, setActiveView] = useState('executive');
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const renderView = () => {
    switch (activeView) {
      case 'executive': return <ExecutiveSummary />;
      case 'channel': return <ChannelBreakdown />;
      case 'campaign': return <CampaignDrillDown />;
      case 'quality': return <LeadQualityMatrix />;
      case 'lost': return <LostLeadAnalysis />;
      case 'sales': return <DailySalesReport />;
      default: return <ExecutiveSummary />;
    }
  };

  return (
    <div className="flex h-full" style={{ minHeight: '100vh' }}>
      {/* Sidebar */}
      <aside
        className="bg-slate-900 text-white flex flex-col transition-all"
        style={{ width: sidebarOpen ? 260 : 70, minWidth: sidebarOpen ? 260 : 70 }}
      >
        {/* Logo */}
        <div className="flex items-center gap-3 p-4 border-b" style={{ borderColor: '#334155' }}>
          <div className="flex items-center justify-center rounded-lg bg-blue-600" style={{ width: 36, height: 36 }}>
            <TrendingUp size={20} className="text-white" />
          </div>
          {sidebarOpen && (
            <div>
              <div className="font-bold text-sm">Attribution</div>
              <div className="text-xs text-slate-400">Dashboard</div>
            </div>
          )}
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-3 gap-1 flex flex-col overflow-y-auto">
          {NAV_ITEMS.map(item => {
            const Icon = item.icon;
            return (
              <div
                key={item.id}
                className={`nav-item ${activeView === item.id ? 'active' : ''}`}
                onClick={() => setActiveView(item.id)}
                title={!sidebarOpen ? item.label : ''}
              >
                <Icon size={18} />
                {sidebarOpen && <span>{item.label}</span>}
              </div>
            );
          })}
        </nav>

        {/* Status */}
        {sidebarOpen && (
          <div className="p-4 border-t" style={{ borderColor: '#334155' }}>
            <div className="flex items-center gap-2 mb-2">
              <div className="rounded-full bg-emerald-500" style={{ width: 8, height: 8 }} />
              <span className="text-xs text-slate-400">Meta API: Live</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="rounded-full bg-amber-500" style={{ width: 8, height: 8 }} />
              <span className="text-xs text-slate-400">Google API: Simulated</span>
            </div>
          </div>
        )}

        {/* Toggle */}
        <div
          className="p-3 border-t cursor-pointer text-slate-400 hover:text-white transition"
          style={{ borderColor: '#334155' }}
          onClick={() => setSidebarOpen(!sidebarOpen)}
        >
          <div className="flex items-center justify-center">
            <Activity size={18} />
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white border-b sticky top-0 z-10">
          <div className="flex items-center justify-between px-6 py-3">
            <div>
              <h1 className="text-xl font-bold text-slate-800">
                {NAV_ITEMS.find(i => i.id === activeView)?.label}
              </h1>
              <p className="text-sm text-slate-500">Education Enrollment Attribution</p>
            </div>
            <div className="flex items-center gap-3">
              <DateRangeSelector />
              <PlatformFilter />
              <div className="flex items-center gap-2 bg-blue-50 border border-blue-200 rounded-lg px-3 py-2">
                <div className="rounded-full bg-blue-500" style={{ width: 8, height: 8 }} />
                <span className="text-sm font-medium text-blue-700">Demo Mode</span>
              </div>
            </div>
          </div>
        </header>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          <div className="animate-fade-in">
            {renderView()}
          </div>
        </div>
      </main>
    </div>
  );
}
